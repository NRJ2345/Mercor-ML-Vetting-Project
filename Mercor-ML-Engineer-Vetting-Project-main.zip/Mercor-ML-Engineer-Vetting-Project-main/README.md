# Mercor-ML-Engineer-Vetting-Project

#Makefile
First install any required directories using pip install name of the directories.
#Explanation
1.	Here, we have extracted Price, Name, and URL data using AutoScraper.
2.	After extracting, we put these data into columns of data then converted to CSV file
3.	Lastly, we have created the compute_similarity function which compares the given text to find and return the most similar 'URLs' results on the basis of the top_n we have provided like to find the top 2 of this text from these data.

